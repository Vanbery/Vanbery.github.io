//#region PreLoad
/*function loadFile(filePath, done) {
	let request = new XMLHttpRequest();
	request.onload = function () { return done(this.responseText) }
	request.open('GET', filePath, true);
	request.send();
}*/

attach(window,'load',function(){
	
    fadeOut(document.getElementById('loader'),1,0,30,function(cb){
		Initial();
		document.getElementById('loader').style.display = 'none';
    });	

},false);

const Files = [ 'CityCountyData.json', 'json.json'];

var CityData = [];

async function Initial() {
	
	for(const [i, v] of Files.entries()){
		let url = 'https://vanbery.github.io/Json/' + v
		let result = await fetch(url);
		CityData[i] = await result.json();
	}
	
	readFunction(CityData[0]);
	admin_onchange('0');
}



/*Files.forEach(function (file, i) {
	let url = "https://vanbery.github.io/Json/" + file;
	loadFile(url, function (responseText){
		CityData[i] = JSON.parse(responseText);
		if(i === 0){ //爛方法
			readFunction(CityData[i]);
		}
	});
});*/

//#region PreLoad

function readFunction(arr) {
	//先讀行政區域資料
	for (let data of arr) {
		let options = document.createElement("option");
		let name = document.createTextNode(data.CityName);
		options.value = data.CityName
		options.appendChild(name);
		document.getElementById('admin_zone').appendChild(options);
	}
}
//行政區選擇
function admin_onchange(value) {
	//先重置鄉鎮區域
	town_reset();
	
	let selected_style = document.getElementsByClassName('style_selected')[0].id;
	
	if (value === "0") {
		//撈資料
		ReadData('admin', selected_style, 1);
	} else {
		let town_result = CityData[0].find(e => e.CityName === value);
		
		//鄉鎮區域選單資料
		for (let r of town_result.AreaList) {
			let options = document.createElement("option");
			let name = document.createTextNode(r.AreaName);
			options.value = r.AreaName
			options.appendChild(name);
			document.getElementById('town_zone').appendChild(options);
		}
		
		//撈資料
		ReadData(value, selected_style, 1);
	}	
}
function town_onchange(value) {
	let selected_style = document.getElementsByClassName('style_selected')[0].id;
	//console.log(selected_style);
	if (value === "0") {
		//撈資料
		ReadData('town', selected_style, 1);
	} else {
		//撈資料
		ReadData(value, selected_style, 1);
	}
}

//鄉鎮區重置
function town_reset() {
	document.getElementById('town_zone').innerText = null;
	let options = document.createElement('option');
	let name = document.createTextNode('請選擇鄉鎮區域');
	options.value = '0';
	options.appendChild(name);
	document.getElementById('town_zone').appendChild(options);
}

function ReadData(region, style, current_page) {
	//資料重置
	DataRest();
	console.log(current_page);
	let body = document.getElementsByClassName('data_row')[0];
	let tbl;
	let tbody = document.createElement('tbody');
	
	
	if(region === 'town') {
		let e = document.getElementById('admin_zone');
		region = e.options[e.selectedIndex].value;
	}
	
	if(region === 'admin'){ //行政區全撈
		//分頁取部份資料
		let data = Pages(CityData[1], current_page); 
		//取得數量
		let length = data.length;
		
		if (style === 'list'){
			tbl = document.getElementById('list_data');
			for(var i = 0; i < length; i++) {
				TableCreateList(tbody, data[i]);				
			}
			//PicURL, City, Town, Name, HostWords(FoodFeatures)
		} else if (style === 'menu'){
			tbl = document.getElementById('table');
			
			TableCreateTH(tbody); //建Title
			for(var i = 0; i < length; i++){	
				let tr = document.createElement('tr');
				for(var j = 0; j < 5; j++){ //欄位數5
					TableCreateTD(tr, j, i, data[i])
				}
				tbody.appendChild(tr);
			}
		}
	} else {
		let result = CityData[1].filter(e => e.City === region); //撈不到會是空值
				
		if (result.length == 0) { //非行政區
			result = CityData[1].filter(e => e.Town === region);
		}
		//分頁取部份資料
		let data = Pages(result, current_page); 
		
		if (style === 'list'){
			tbl = document.getElementById('list_data');
			for(var i = 0; i < data.length; i++) {
				TableCreateList(tbody, data[i]);				
			}
		} else if (style === 'menu'){
			tbl = document.getElementById('table');
			TableCreateTH(tbody); //建Title
			for(var i = 0; i < data.length; i++){	
				
				let tr = document.createElement('tr');
				for(var j = 0; j < 5; j++){ //欄位數5
					TableCreateTD(tr, j, i, data[i])
				}
				tbody.appendChild(tr);
			}
		}
	}
	
	tbl.appendChild(tbody);
	body.appendChild(tbl);
}

function TableCreateList(tbody, data) {
	let tr = document.createElement('tr');
	tbody.appendChild(tr);
	
	let td = document.createElement('td');
	td.classList.add('center');
	td.classList.add('screen_display');
	td.bgColor = '#84C1FF'
	td.height = '30px';
	td.maxWidth = '50px';
	td.appendChild(document.createTextNode(data.City)); 
	tr.appendChild(td);
	
	let td_c = document.createElement('td');
	td_c.bgColor = '#FFFFFF';
	td_c.rowSpan = 2;
	td_c.style.maxWidth = '880px';
	
	let div = document.createElement('div');
	div.style = 'display: inline-block';
	let img = document.createElement('img');
	img.src = data.PicURL;
	img.style.height = '300px';
	img.style.width = '400px';
	div.appendChild(img);
	td_c.appendChild(div);
	
	let div_c = document.createElement('div');
	div_c.style = 'display: inline-block; vertical-align: top;';
	
	
	//如果有url就用連結
	if(data.Url === '') {
		let span = document.createElement('span');
		span.textContent = data.Name;
		span.style = 'font-size: 24px; font-weight: bold;';
		div_c.appendChild(span);
	} else {
		let url = document.createElement('a');
		let url_text = document.createTextNode(data.Name);
		url.appendChild(url_text);
		url.href = data.Url;
		url.target = '_blank';
		url.style = 'font-size: 24px; font-weight: bold;';
		div_c.appendChild(url);		
	}
	
	div_c.appendChild(document.createElement('br'));
	
	let moblie_span_city = document.createElement('span');
	moblie_span_city.textContent = data.City;
	moblie_span_city.style.backgroundColor = '#84C1FF';
	moblie_span_city.classList.add('moblie_display');
	div_c.appendChild(moblie_span_city);
	let moblie_span_town = document.createElement('span');
	moblie_span_town.textContent = data.Town;
	moblie_span_town.classList.add('moblie_display');
	div_c.appendChild(moblie_span_town);
	div_c.appendChild(document.createElement('br'));
	div_c.appendChild(document.createElement('br'));
	
	let span_c = document.createElement('span');
	span_c.classList.add('text-shenglue');
	span_c.style.maxWidth = '470px';
	span_c.textContent = data.HostWords;
	div_c.appendChild(span_c);
	
	td_c.appendChild(div_c);
	tr.appendChild(td_c);
	
	let tr_t = document.createElement('tr');
	tbody.appendChild(tr_t);
	let td_t = document.createElement('td');
	td_t.align = 'right';
	td_t.style.verticalAlign = "top";
	
	let span_t = document.createElement('span');
	span_t.classList.add('vertical-mode');
	span_t.classList.add('screen_display');
	span_t.textContent = data.Town;
	td_t.appendChild(span_t);
	tr_t.appendChild(td_t);
}

function TableCreateTH(tbody){
	let text = ['編號', '行政區域', '鄉鎮區', '商家', '地址'];
	let tr = document.createElement('tr');
	for(let txt of text){
		let th = document.createElement('th');
	
		th.style.padding = '10px 10px 10px 10px';
		th.style.backgroundColor = '#E0E0E0';
		th.style.color = '#9D9D9D';
		if(txt === '商家') {
			th.style.width = '150px';
		} else if (txt === '地址') {
			th.style.width = '550px';
		}
	
		th.appendChild(document.createTextNode(txt));
		tr.appendChild(th);
	}
	tbody.appendChild(tr);
}

function TableCreateTD(tr, j, i, data){
	let td = document.createElement('td');
	td.style.padding = '10px 10px 10px 10px';
	if(i % 2 > 0) {
		//偶數灰格
		tr.style.backgroundColor = '#F0F0F0';
	} else {
		tr.style.backgroundColor = '#FFFFFF';
	}
	//1 編號 2行政區域 3鄉鎮區 4商家 5地址
	//編號根據頁數來增加
	switch(j){
		case 0:
			td.style.textAlign = 'right';
			let currentPage = parseInt(document.getElementsByClassName('page-current')[0].innerHTML);
			if(currentPage > 1) {
				td.appendChild(document.createTextNode(i+1+((currentPage-1)*10)));
			} else {
				td.appendChild(document.createTextNode(i+1));
			}
			break;
		case 1:
			td.appendChild(document.createTextNode(data.City));
			break;
		case 2:
			td.appendChild(document.createTextNode(data.Town));
			break;
		case 3:
			td.appendChild(document.createTextNode(data.Name));
			break;
		case 4:
			td.appendChild(document.createTextNode(data.Address));
			break;
	}
	tr.appendChild(td);
}

function DataStyle(style){
	let region = '';
	let selected_style = document.getElementsByClassName('style_selected');
	selected_style[0].removeAttribute("style");
	selected_style[0].classList.remove('style_selected');
	
	let e = document.getElementById(style);
	e.style = 'border: 2px solid red;';
	e.classList.add('style_selected');
	
	DataRest();
	
	let a = document.getElementById('admin_zone');
	let a_value = a.options[a.selectedIndex].value
	let t = document.getElementById('town_zone');
	let t_value = t.options[t.selectedIndex].value
	
	if (a_value === '0') {
		region = 'admin';
	} else {
		if(t_value === '0') {
			region = 'town';
		} else {
			region = t.options[t.selectedIndex].value;
		}
	}
	
	let currentPage = document.getElementsByClassName('page-current')[0].innerHTML;
	
	ReadData(region, style, currentPage);
	
	switch(style){
		case 'list':
			document.getElementById('list_data').hidden = false;
			document.getElementById('table').hidden = true;
			document.getElementById('grid_data').hidden = true;
			break;
		case 'menu':	
			
			document.getElementById('list_data').hidden = true;
			document.getElementById('table').hidden = false;
			document.getElementById('grid_data').hidden = true;
			break;
		case 'grid':
			document.getElementById('list_data').hidden = true;
			document.getElementById('table').hidden = true;
			document.getElementById('grid_data').hidden = false;
			break;
	}
	
}

//reion Utitily
function DataRest() {
	let tables = document.getElementsByTagName('table');
	let tbs = document.getElementsByTagName('tbody');
	
	if(tables != null){
		for(let table of tables){
			while (table.rows.length>0) { 
				table.deleteRow(0) 
			}
		}
		for(let tbody of tbs){
			tbody.parentNode.removeChild(tbody);
		}
	}
}

function Pages(data, currentPage){
	//總資料筆數
	const dataTotal = data.length;
	//每一頁顯示10筆資料
	const perpage = 10;
	// page 按鈕總數量公式 總資料數量 / 每一頁要顯示的資料
	const pageTotal = Math.ceil(dataTotal / perpage);
	//console.log('全部資料:' + dataTotal + ' 每一頁顯示:' + perpage + '筆 總頁數:' + pageTotal);
	// 當"當前頁數"比"總頁數"大的時候，"當前頁數"就等於"總頁數"
	if (currentPage > pageTotal) {
		currentPage = pageTotal;
	}
	//最小值
	const minData = (currentPage * perpage) - perpage + 1;
	//console.log('最小值:' + minData);
	//最大值
	const maxData = (currentPage * perpage);
	//console.log('最大值:' + maxData);
	
	//建立新陣列
	const page_data = [];
	data.forEach((item, index) => {
		const num = index + 1;
		// 當 num 比 minData 大且又小於 maxData 就push進去新陣列。
		if ( num >= minData && num <= maxData) {
			page_data.push(item);
		}
	})
	//處理分頁產生
	const page = {
		pageTotal,
		currentPage,
		hasPage: currentPage > 1,
		hasNext: currentPage < dataTotal,
	}
	
	pageBtn(page);
	
	return page_data;
}

function pageBtn (page){
	let str = '';
	const total = page.pageTotal;
	
	for(let i = 1; i <= total; i++){
		if(Number(page.currentPage) === i) {
			str +='<a class="pages page-current" href="javascript: switchPage(' + i + ')">' + i +'</a>';
		} else {
			str +='<a class="pages" href="javascript: switchPage(' + i + ')">' + i +'</a>';
		}
	};
	let pageid = document.getElementById('page');
	pageid.innerHTML = str;
	
	let pc = document.getElementById('page-count');
	pc.innerHTML = '美食頁次 ' + page.currentPage + ' / ' + page.pageTotal;
}

function switchPage(i){
	let selected_style = document.getElementsByClassName('style_selected')[0].id;
	let cs = document.getElementById('admin_zone');
	let city_selected = cs.options[cs.selectedIndex].value;
	let region = 'admin'; //預設
	
	if(city_selected === "0") {
		region = 'admin';
	} else {
		let ts = document.getElementById('town_zone');
		let town_selected = ts.options[ts.selectedIndex].value;
		
		if(town_selected === "0") {
			region = 'town';
		} else {
			region = town_selected;
		}
	}
	
	ReadData(region, selected_style, i);
}

function attach(element,listener,ev,tf){

	if(element.attachEvent) {

		element.attachEvent("on"+listener,ev);

	} else {

		element.addEventListener(listener,ev,tf);

	}
}

function fadeOut(element,startLevel,endLevel,duration,callback){

	var fOInt;

    op = startLevel;

	fOInt = setInterval(function() {

		if(op<=endLevel){

			element.style.opacity = endLevel;
			element.style.filter = "alpha(opacity = " + endLevel + ")";

			clearInterval(fOInt);

			if(typeof callback == 'function') {
				callback(true);
			}

		} else {

			op -= 0.1;

			element.style.opacity = op;
			element.style.filter = "alpha(opacity = " + op*100 + ")";

		}

    },duration);
}

//